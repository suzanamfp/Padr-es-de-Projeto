package teste;

import model.Mp3Player;
import model.Player;
import model.WmvPlayer;

public class TemplatePrincipal {
	
	public static void main(String[] args) {
		
		Player tocador = new Mp3Player();
		tocador.executar();
		
		System.out.println("-------------------");
		
		tocador = new WmvPlayer();
		tocador.executar();
		
		
	}

	
}
