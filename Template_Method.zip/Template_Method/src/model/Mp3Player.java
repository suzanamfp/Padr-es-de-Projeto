package model;

public class Mp3Player extends Player{

	@Override
	public void play() {
		System.out.println("Executando uma m�sica Mp3....");
		
	}

	@Override
	public void stop() {
		System.out.println("Parando uma m�sica Mp3....");
		
	}

	@Override
	public void avancar() {
		System.out.println("Avan�ando uma m�sica Mp3....");
		
	}

}
