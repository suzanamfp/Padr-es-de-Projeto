package Teste;

import model.Contexto;
import model.Divisao;
import model.Multiplicacao;
import model.Soma;
import model.Subtracao;

public class Principal {

	public static void main(String[] args) {
		

		Contexto contexto = new Contexto(new Soma());
		System.out.println("Usando a estrat�gia de soma, o resultado �: " + contexto.executaStrategy(4, 4)); 
	
		Contexto contexto2 = new Contexto(new Subtracao());
		System.out.println("Usando a estrat�gia de subtra��o, o resultado �: " + contexto2.executaStrategy(10, 7)); 
		
		Contexto contexto3 = new Contexto(new Divisao());
		System.out.println("Usando a estrat�gia de divis�o, o resultado �: " +contexto3.executaStrategy(20, 2));
		 
		Contexto contexto4 = new Contexto(new Multiplicacao());
		System.out.println("Usando a estrat�gia de soma, o resultado �: " + contexto4.executaStrategy(6, 4));//24
		
		
		

	}

}
