package model;

public class Multiplicacao implements Calculadora {

	@Override
	public int operacao(int num1, int num2) {
		return (num1*num2);//Estrat�gia de multiplica��o
	}
	

}
