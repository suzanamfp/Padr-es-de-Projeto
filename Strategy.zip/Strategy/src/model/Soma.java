package model;

public class Soma implements Calculadora{

	@Override
	public int operacao(int num1, int num2) {
		return (num1 + num2); //Estrat�gia de soma
	}

}
