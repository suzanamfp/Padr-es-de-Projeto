package model;

public class Contexto {
	
	public Calculadora calculadoraStrategy;
	
	public Contexto(Calculadora calc) {
		this.calculadoraStrategy = calc;
	}
	
	public int executaStrategy(int num1, int num2) { //executa a estrat�gia (opara��o) escolhida
		return calculadoraStrategy.operacao(num1, num2);
	}

}

