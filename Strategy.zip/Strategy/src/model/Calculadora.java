package model;

//O Strategy � um padr�o de projeto comportamental que permite que voc� defina uma fam�lia de algoritmos, 
//coloque-os em classes separadas, e fa�a os objetos deles intercambi�veis.

public interface Calculadora {
	
	public int operacao(int num1, int num2);

}
