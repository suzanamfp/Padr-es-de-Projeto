package Principal;


import model.FlorFactory;

public class Teste {
	
	public static void main(String[] args) {
		
		FlorFactory tipoFlor =  new FlorFactory();
		
		tipoFlor.criarNovasFlores("Rosa").criarFlor();
		
		tipoFlor.criarNovasFlores("Margarida").criarFlor();
		
		tipoFlor.criarNovasFlores("Orquidea").criarFlor();
		
	}

}
