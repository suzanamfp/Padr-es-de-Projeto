package model;

public interface Flor {
	
	public void criarFlor();
	
	

}
