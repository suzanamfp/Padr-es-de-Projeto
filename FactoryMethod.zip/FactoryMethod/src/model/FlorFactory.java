package model;

public class FlorFactory {
	
	public Flor criarNovasFlores(String flor) { // a partir de um �nico m�todo crio novos objetos
		
		if (flor == "" || flor == null) {
			return null;
		}
		
		if (flor.equals("Rosa")) {
			return new Rosa();	
		}else if (flor.equals("Margarida")) {
			return new Margarida();
		}else if (flor.equals("Orquidea")) {
			return new Orquidea();
		}
		
		return null;			
	}

	
	
	
}
