package model;

public class Rosa implements Flor{

	@Override
	public void criarFlor() {
		System.out.println("Uma rosa foi criada");
		
	}

}
