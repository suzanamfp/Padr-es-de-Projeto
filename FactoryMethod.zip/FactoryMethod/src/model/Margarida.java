package model;

public class Margarida implements Flor {

	@Override
	public void criarFlor() {
		System.out.println("Margarida foi criada");
		
	}

}
