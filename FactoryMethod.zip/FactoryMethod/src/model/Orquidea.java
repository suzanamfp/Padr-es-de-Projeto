package model;

public class Orquidea implements Flor {

	@Override
	public void criarFlor() {
		System.out.println("Orqu�dea foi criada");
		
	}

}
