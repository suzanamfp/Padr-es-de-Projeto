package principal;

import model.CriadorDeNotaFiscal;
import model.ItensDaNota;
import model.NotaFiscal;

public class Teste { 
	
	public static void main(String[] args) {
	
	CriadorDeNotaFiscal builder = new CriadorDeNotaFiscal();
	builder.inserirRazaoSocial("Empresa");
	builder.inserirCnpj("00000000");
	builder.inserirObs("Informa��es adicionais");
	builder.item(new ItensDaNota (("item 1"), 200.0));
	builder.item(new ItensDaNota (("item 2"), 300.0));
	builder.item(new ItensDaNota (("item 3"), 400.0));
	
	NotaFiscal nf = builder.contruirNota();
	
	System.out.println(nf.getValor());
	
	}
}

