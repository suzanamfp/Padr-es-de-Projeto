package model;

import java.util.ArrayList;
import java.util.List;

public class CriadorDeNotaFiscal {
	
	private String razaoSocial;
	private String cnpj;
	private double valorTotal;
	private double impostos;
	public List<ItensDaNota> itens = new ArrayList<ItensDaNota>();
	public String obs;

	
	public void inserirRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}
	
	public void inserirCnpj(String cnpj) {
		this.cnpj = cnpj;
	}
	
	public void item(ItensDaNota item) {
		itens.add(item);
		valorTotal += item.getValor();
		impostos += item.getValor() *0.05;
	}
	
	public void inserirObs(String obs) {
		this.obs = obs;
	}
	
	
	public NotaFiscal contruirNota() {
		return new NotaFiscal(razaoSocial, cnpj, valorTotal, impostos, itens, obs);
	}

}
