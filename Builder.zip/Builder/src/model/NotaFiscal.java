package model;

import java.util.List;


public class NotaFiscal {
	
	private String razaoSocial;
	private String cnpj;
	private double valorTotal;
	private double impostos;
	public List<ItensDaNota> itens;
	public String obs;
	

	public NotaFiscal(String razaoSocial, String cnpj, double valor, double impostos, List<ItensDaNota> itens,
			String obs) {
		super();
		this.razaoSocial = razaoSocial;
		this.cnpj = cnpj;
		this.valorTotal = valor;
		this.impostos = impostos;
		this.itens = itens;
		this.obs = obs;
	}


	public String getRazaoSocial() {
		return razaoSocial;
	}


	public void setRazaoSocial(String razaoSocial) {
		this.razaoSocial = razaoSocial;
	}


	public String getCnpj() {
		return cnpj;
	}


	public void setCnpj(String cnpj) {
		this.cnpj = cnpj;
	}


	public double getValor() {
		return valorTotal;
	}


	public void setValor(double valor) {
		this.valorTotal = valor;
	}


	public double getImpostos() {
		return impostos;
	}


	public void setImpostos(double impostos) {
		this.impostos = impostos;
	}


	public List<ItensDaNota> getItens() {
		return itens;
	}


	public void setItens(List<ItensDaNota> itens) {
		this.itens = itens;
	}


	public String getObs() {
		return obs;
	}


	public void setObs(String obs) {
		this.obs = obs;
	}
	
	
	
	
	
	
}
