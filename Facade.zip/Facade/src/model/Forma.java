package model;


public interface Forma {
	
	public void desenharForma();

}
