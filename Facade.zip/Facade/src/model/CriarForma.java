package model;

public class CriarForma {// criando as formas por meio de m�todos
	
	private Forma hexagonal;
	private Forma quadrilatero;
	
	
	
	public CriarForma() {
		hexagonal = new Hexagono();
		quadrilatero = new Quadrilatero();	
	}
	
	
	public void criarHexagono() {
		hexagonal.desenharForma();
	}
	
	public void criarQuadrilatero() {
		quadrilatero.desenharForma();
	}
	
	

}
