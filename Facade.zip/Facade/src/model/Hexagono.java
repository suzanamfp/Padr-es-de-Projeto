package model;

public class Hexagono implements Forma{

	@Override
	public void desenharForma() {
		System.out.println("Desenhando um hex�gono");
		
	}

}
