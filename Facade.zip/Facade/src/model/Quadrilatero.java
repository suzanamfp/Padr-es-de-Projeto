package model;

public class Quadrilatero implements Forma{

	@Override
	public void desenharForma() {
		System.out.println("Desenhando um quadrado");
		
	}

}
