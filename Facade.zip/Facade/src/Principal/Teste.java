package Principal;

import model.CriarForma;

public class Teste {
	
	public static void main(String[] args) {
		
		CriarForma criandoForma = new CriarForma();
		
		criandoForma.criarHexagono();
		criandoForma.criarQuadrilatero();
	}

}

//Vantagem
// - Isolar o c�digo de outros subsistemas
